<# 
 # the aim of this script is to gather all the current logs from
 #
 # 1. event-viewer (all PIMO today, all PIVOT today, all errors from "Application", "System" and "Security" Logs)
 # 2. pivotalclient.log
 # 3. uxclient.log
 # 4. OfficeIntegration.log
 #
 # the logs are saved to c:\pivotallogs
 # please compress them into a .zip file and attach to the ticket
 #>

function throwException ($exceptionType) {
    Write-Host "The log related to $exceptionType could not be retrived." -ForegroundColor Red
    
}

function writeOutro {

    Write-Host @"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                                                    
Even if not all logs were retrieved, there should still be some in
the folder c:\pivotalLogs\
Please attach them to the existing ticket.

Thanks, 
Pivotal Support Team
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"@ -ForegroundColor cyan
}

function openLogFolder {
    Start-Process "$pivotalLogFolder" -WindowStyle Maximized
}

function compressLogs {
    if ((Get-Host).Version.Major -gt 4) {
        Compress-Archive "$pivotalLogFolder\*.*" -DestinationPath "$pivotalLogFolder\pivotal_logs.zip" -Force
        Get-ChildItem  $pivotalLogFolder -exclude *.zip | Remove-Item
    }
}

function getEventViewerLog {
    param (
        [array]$provider
    )
    try {
        Get-WinEvent -FilterHashtable @{ProviderName = "*pivotal*"; StartTime = (Get-Date).date } -ErrorAction SilentlyContinue | Select-Object LogName, ProviderName, TimeCreated, LevelDisplayName, Message | Format-List | Out-File "$pivotalLogFolder\pivotal_event_viewer.txt" -Force 
    }
    catch {
        throwException -exceptionType "Pivotal"
    }
    try {
        Get-WinEvent -FilterHashtable @{ProviderName = "*outlook*"; StartTime = (Get-Date).date } -ErrorAction SilentlyContinue | Select-Object LogName, ProviderName, TimeCreated, LevelDisplayName, Message | Format-List | Out-File "$pivotalLogFolder\outlook_event_viewer.txt" -Force    
    }
    catch {
        throwException -exceptionType "Outlook"
    }
        
    try {
        Get-WinEvent -FilterHashtable @{LogName = "Application", "System", "Security"; Level = 1, 2, 3; StartTime = (Get-Date).date } -ErrorAction SilentlyContinue | Select-Object LogName, ProviderName, TimeCreated, LevelDisplayName, Message | Format-List | Out-File "c:\pivotallogs\errors_eventViewer.txt" -Force    
    }
    catch {
        throwException -exceptionType "System, Application or Security"
    }
            
}
function getUXClientLog {
    if (Test-Path "C:\Program Files (x86)\Aptean") {
        Copy-Item "C:\Program Files (x86)\Aptean\Pivotal CRM\UX Client\www\logs\UXServer.log" -Destination $pivotalLogFolder
    }
    elseif (Test-Path "C:\Program Files (x86)\CDC Software\") {
        Copy-Item "C:\Program Files (x86)\CDC Software\Pivotal CRM\UX Client\www\logs\UXServer.log" -Destination $pivotalLogFolder
    }
    else { throwException -exceptionType "UX Client" }
}
        
function getPivotalClientLog {
    if (Test-Path "$env:userprofile\AppData\Roaming\CDC Software") {
        Push-Location "$env:userprofile\AppData\Roaming\CDC Software"
        Get-ChildItem PivotalClient.log -rec | ForEach-Object {
            $fileName = $_.Name;
            $destinationPath = $pivotalLogFolder + "\" + $fileName;
            if (Test-Path $destinationPath) {
                $i = 0;
                while (Test-Path $destinationPath) {
                    $i++;
                    $destinationPath = "$pivotalLogFolder\PivotalClient_$i.log";    
                };
            }
            Copy-Item $_.FullName -Destination $destinationPath;
            Pop-Location
        }
    }
    else { throwException -exceptionType "Pivotal SmartClient" }
            
}
function getPIMOLogs {
    if (Test-Path "$env:userprofile\CDC Software\OfficeIntegration.log") {
        Copy-Item "$env:userprofile\CDC Software\OfficeIntegration.log" -Destination $pivotalLogFolder
    }
    else { throwException -exceptionType "Pivotal Outlook Add-in" }
}

function writeIntro {

    Write-Host @"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                                                    
the aim of this script is to gather all the current logs from

1. event-viewer logs for pivotal and outlook (for today only!)
2. pivotalclient.log 
3. uxclient.log
4. OfficeIntegration.log

the logs are saved to c:\pivotallogs
if you find a .zip file, attach it to the ticket; 
if you find a a collection of log files, please zip them first
... the above depends on the version of your powershell    
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
"@ -ForegroundColor cyan
}

function getPivotLogs {
    param (
        [array]$provider
    )

    $pivotalLogFolder = "c:\pivotallogs\";
    if (!(Test-Path $pivotalLogFolder)) {
        mkdir $pivotalLogFolder | Out-Null
    }
    writeIntro;
    getPIMOLogs;
    getPivotalClientLog;
    getUXClientLog;
    getEventViewerLog -provider $provider;
    compressLogs;
    writeOutro;
    Pause
    openLogFolder;
}
getPivotLogs