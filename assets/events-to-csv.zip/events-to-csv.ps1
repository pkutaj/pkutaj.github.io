Write-Host @"
* this script tries to convert all event logs from the current folder into a .csv file 
* technically, it first converts it to an .xml and creates a .csv from there
* that you can import to Excel/Sheets for further analysis / aggregation / filtering, etc.
* it may take some times, please exercise some patience
--------------------------------------------------------------------------------------------
"@
pause

$i = 0;
Get-ChildItem *.evtx | ForEach-Object {
   $i++;
   $todayDate = Get-Date -UFormat "%Y-%m-%d-%H%M%S"
   $filePath = $_.BaseName + "-$todayDate-$i.csv"

$Events = Get-WinEvent -path $_.FullName;

ForEach ($Event in $Events) {            
   # Convert the event to XML            
   $eventXML = [xml]$Event.ToXml()            
   Add-Member -InputObject $Event -MemberType NoteProperty -Force -Name  "detailed_error_message" -Value $eventXML.Event.EventData.Data            
}            
try {
   $Events | Export-Csv .\$filePath               
}
catch {
   write-host "something went wrong"
}
}